# Product Brief: Alchemist

## Background

In the Witch Daddy Labs ecosystem, developers and designers often maintain personal databases of ideas, notes and experiments. These collections are typically stored as local SQLite files because SQLite is ubiquitous, easy to embed, and requires no server. However, when people want to interrogate their own database—for example “Which of my app ideas mention local‑first workflows?”—they face a major bottleneck: they must open a generic database tool and write SQL by hand. This friction stops many from exploring patterns and opportunities hidden in their own data.

**Alchemist** addresses this problem by offering a privacy‑preserving macOS application that lets users open a local SQLite database and ask questions in plain language. The application reads the schema, uses a locally hosted large language model (LLM) to generate safe SQL queries, previews the generated SQL, executes it in read‑only mode, and displays results as tables, summaries or simple charts. The entire workflow happens on the user’s machine, with no requirement to sign up, send data over a network, or run a separate database server. The product is open source and funded through optional donations rather than subscriptions.

## Goals

- Enable indie developers, product designers and creative coders to extract insights from their own SQLite databases without writing SQL.
- Respect privacy: data never leaves the user’s machine and the software runs offline by default.
- Provide a polished, witchy hacker aesthetic consistent with Witch Daddy Labs: dark backgrounds, neon accents, clean typography.
- Maintain simplicity: limited scope at first (SQLite only, read‑only) to deliver reliability and trust.
- Build a community‑driven open‑source tool that people can extend; revenue comes from voluntary donations rather than mandatory fees.

## Target Users

- **Indie builders and coders** who keep notes, prototypes and brainstorms in local databases and want to query them quickly.
- **Creative designers and product strategists** who organise idea vaults or research in SQLite and need an approachable way to explore patterns.
- **Developers working with Supabase/Postgres** for side projects who still appreciate local SQLite for prototypes (future versions may support read‑only Postgres connections).
- **Privacy‑conscious users** who refuse to upload their proprietary data to cloud services or third‑party APIs.

## Problems and Pain Points

- **SQL intimidation:** Many creative users are not fluent in SQL; writing queries is time‑consuming and error‑prone.
- **Tool overhead:** General‑purpose database GUIs (e.g., DBeaver, DataGrip) are heavy, require manual configuration and feel overkill for personal archives.
- **Privacy concerns:** Cloud‑based “chat with your data” services send table schemas and query context to remote servers, which is unacceptable for proprietary or sensitive content.
- **UX friction:** Existing tools treat chat‑based BI like a SaaS dashboard builder; they feel business‑oriented rather than personal.

## Solution Overview

Alchemist is a native macOS application that:

1. **Opens local SQLite files** in read‑only mode. Users drag a `.db`/`.sqlite` file into the app or choose it via the file picker.
2. **Introspects the schema** to identify tables, columns, relationships and field descriptions, then displays them in a side panel.
3. **Provides a chat console** where users ask questions in natural language. The prompt can be anything from simple lookups (“List all ideas tagged AI”) to more elaborate tasks (“Find themes that recur in my ideas tagged workflow”).
4. **Generates SQL** using a local LLM (via Ollama or similar). The app sends the schema and the question to the LLM, which returns a single SQL statement that abides by strict safety rules (SELECT‑only, single statement, limited rows).
5. **Previews the SQL** before it runs. Users see the generated SQL and can edit it or decline to run it.
6. **Executes in read‑only mode** against the SQLite file; the app rejects any destructive statements and enforces row limits.
7. **Displays results** in a table with optional summaries and simple charts (e.g. bar or line charts for counts over time).
8. **Saves query history and reusable prompts** (“spells”) so users can repeat or modify previous questions.
9. **Lives fully offline**; nothing is sent to remote services unless the user explicitly opts‑in to a cloud model (non‑MVP).

## Unique Differentiators

- **Local‑first:** Runs entirely on the user’s machine; no network calls are needed.
- **Read‑only safety:** Prevents destructive queries and ensures the database remains unchanged.
- **Polished, magical aesthetic:** Inspired by tools like Cursor, Replit and dark hacker themes, but with a neon witchy twist.
- **Open source and donation‑funded:** Encourages community contributions without locking core functionality behind subscriptions.
- **Narrow focus:** Prioritises SQLite and simple charts instead of trying to be a full business intelligence platform.

## High‑Level Feature List

- Open/read‑only SQLite database files.
- Schema inspection panel with table/column browsing and plain‑English hints.
- Natural language chat interface for query generation.
- Local LLM integration for SQL generation (via Ollama or similar).
- SQL preview with edit/cancel options.
- Safe query execution layer that enforces SELECT‑only, single‑statement, limited results.
- Results displayed as tables and basic charts (bar, line, pie).
- Saved “spells” for repeating useful queries.
- Dark/neon UI with customisable themes.
- Optional donation link within the app and GitHub Sponsors integration.

## Constraints and Non‑Goals

- **No write operations:** Alchemist does not allow INSERT, UPDATE, DELETE, schema modifications or PRAGMA changes.
- **No multi‑statement SQL:** Only single SELECT or WITH queries are allowed; the app rejects anything else.
- **No cloud requirement:** MVP runs without an Internet connection. Only future extensions may offer remote LLMs.
- **No multi‑user features:** There is no team collaboration; the app is meant for personal use.
- **No enterprise dashboards:** Alchemist is not a BI platform and does not implement complex visualisations beyond simple charts.

## Success Metrics

- **User adoption:** Number of downloads or clones on GitHub; contributions and stars.
- **Query success rate:** Percentage of natural‑language questions that produce correct SQL and meaningful results.
- **Safety integrity:** Zero incidents of unintended database modifications or data leaks.
- **Donation conversion:** Percentage of users who voluntarily support the project financially.
- **Community engagement:** Number of pull requests/issues and quality of contributions.

## Roadmap (high level)

1. **MVP (v0.1):** macOS app with SQLite support, local model integration, basic charts, saved queries.
2. **v0.2:** Postgres/Supabase read‑only support; improved chart library.
3. **v0.3:** Plugin architecture for other databases (CSV, MySQL) and local data formats.
4. **v1.0:** Signed builds, auto‑update mechanism, cross‑platform (Windows/Linux) support, optional remote LLM integration.
